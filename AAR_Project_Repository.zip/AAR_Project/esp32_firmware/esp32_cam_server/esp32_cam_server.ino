/**
 * ============================================================
 *  AAR - Automated Attendance Register
 *  ESP32-CAM Firmware: MJPEG Web Server (Acquisition Node)
 * ============================================================
 *
 *  HARDWARE REQUIRED:
 *    - ESP32-CAM (AI Thinker model recommended)
 *    - FTDI USB-to-TTL programmer (for flashing)
 *
 *  HOW TO FLASH:
 *    1. Connect FTDI to ESP32-CAM:
 *       FTDI GND  → ESP32 GND
 *       FTDI VCC  → ESP32 5V
 *       FTDI TX   → ESP32 UOR (GPIO3)
 *       FTDI RX   → ESP32 UOT (GPIO1)
 *       FTDI GND  → ESP32 IO0  ← IMPORTANT: Hold this LOW during flash
 *    2. Open Arduino IDE, select Board: "AI Thinker ESP32-CAM"
 *    3. Select correct COM port
 *    4. Press Upload. While uploading, IO0 must be connected to GND.
 *    5. After flash completes, DISCONNECT IO0 from GND, then press RESET.
 *
 *  CONFIGURATION:
 *    - Set your hotspot SSID and PASSWORD below.
 *    - The phone running the mobile app MUST create a hotspot
 *      with exactly these credentials.
 *    - After boot, the ESP32 prints its IP address to Serial (115200 baud).
 *      Enter that IP into the mobile app.
 *
 *  STREAM URL FORMAT:
 *    http://<ESP32_IP>:81/stream
 *
 * ============================================================
 */

#include "esp_camera.h"
#include <WiFi.h>
#include "esp_http_server.h"

// ============================================================
//  *** CONFIGURE THESE BEFORE FLASHING ***
// ============================================================
const char* WIFI_SSID     = "AAR_Hotspot";   // Your phone hotspot name
const char* WIFI_PASSWORD = "aar12345";      // Your phone hotspot password
// ============================================================

// AI Thinker ESP32-CAM pin map
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

#define PART_BOUNDARY "123456789000000000000987654321"

static const char* _STREAM_CONTENT_TYPE =
    "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;
static const char* _STREAM_BOUNDARY = "\r\n--" PART_BOUNDARY "\r\n";
static const char* _STREAM_PART =
    "Content-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n";

httpd_handle_t stream_httpd = NULL;

// ─── MJPEG Stream Handler ────────────────────────────────────
static esp_err_t stream_handler(httpd_req_t* req) {
  camera_fb_t* fb = NULL;
  esp_err_t res = ESP_OK;
  char* part_buf[64];

  res = httpd_resp_set_type(req, _STREAM_CONTENT_TYPE);
  if (res != ESP_OK) return res;

  // Prevent caching
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");

  while (true) {
    fb = esp_camera_fb_get();
    if (!fb) {
      Serial.println("[ERROR] Camera capture failed");
      res = ESP_FAIL;
      break;
    }

    size_t hlen = snprintf((char*)part_buf, 64, _STREAM_PART, fb->len);
    res = httpd_resp_send_chunk(req, _STREAM_BOUNDARY, strlen(_STREAM_BOUNDARY));
    if (res == ESP_OK) {
      res = httpd_resp_send_chunk(req, (const char*)part_buf, hlen);
    }
    if (res == ESP_OK) {
      res = httpd_resp_send_chunk(req, (const char*)fb->buf, fb->len);
    }

    esp_camera_fb_return(fb);
    fb = NULL;

    if (res != ESP_OK) break;
  }
  return res;
}

// ─── Health-check endpoint ───────────────────────────────────
static esp_err_t index_handler(httpd_req_t* req) {
  httpd_resp_set_type(req, "text/plain");
  httpd_resp_sendstr(req, "AAR ESP32-CAM Online. Stream: /stream");
  return ESP_OK;
}

// ─── Start HTTP server ───────────────────────────────────────
void startCameraServer() {
  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  config.server_port = 81;

  httpd_uri_t index_uri = {
    .uri       = "/",
    .method    = HTTP_GET,
    .handler   = index_handler,
    .user_ctx  = NULL
  };

  httpd_uri_t stream_uri = {
    .uri       = "/stream",
    .method    = HTTP_GET,
    .handler   = stream_handler,
    .user_ctx  = NULL
  };

  if (httpd_start(&stream_httpd, &config) == ESP_OK) {
    httpd_register_uri_handler(stream_httpd, &index_uri);
    httpd_register_uri_handler(stream_httpd, &stream_uri);
    Serial.println("[OK] HTTP server started on port 81");
  }
}

// ─── Camera initialisation ───────────────────────────────────
void initCamera() {
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer   = LEDC_TIMER_0;
  config.pin_d0       = Y2_GPIO_NUM;
  config.pin_d1       = Y3_GPIO_NUM;
  config.pin_d2       = Y4_GPIO_NUM;
  config.pin_d3       = Y5_GPIO_NUM;
  config.pin_d4       = Y6_GPIO_NUM;
  config.pin_d5       = Y7_GPIO_NUM;
  config.pin_d6       = Y8_GPIO_NUM;
  config.pin_d7       = Y9_GPIO_NUM;
  config.pin_xclk     = XCLK_GPIO_NUM;
  config.pin_pclk     = PCLK_GPIO_NUM;
  config.pin_vsync    = VSYNC_GPIO_NUM;
  config.pin_href     = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn     = PWDN_GPIO_NUM;
  config.pin_reset    = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;

  // Use UXGA only if PSRAM is available; otherwise drop to VGA
  if (psramFound()) {
    config.frame_size   = FRAMESIZE_VGA;   // 640x480 – good balance for recognition
    config.jpeg_quality = 12;              // 0-63, lower = better quality
    config.fb_count     = 2;
  } else {
    config.frame_size   = FRAMESIZE_CIF;   // 352x288 fallback
    config.jpeg_quality = 15;
    config.fb_count     = 1;
  }

  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("[ERROR] Camera init failed: 0x%x\n", err);
    return;
  }

  // Fine-tune sensor settings for classroom lighting
  sensor_t* s = esp_camera_sensor_get();
  s->set_brightness(s, 1);    // Slight brightness boost
  s->set_contrast(s, 1);
  s->set_saturation(s, 0);
  s->set_sharpness(s, 1);
  s->set_whitebal(s, 1);      // Auto white balance ON
  s->set_awb_gain(s, 1);
  s->set_exposure_ctrl(s, 1); // Auto exposure ON
  s->set_aec2(s, 1);
  s->set_ae_level(s, 0);
  s->set_gain_ctrl(s, 1);     // Auto gain ON
  s->set_agc_gain(s, 0);
  s->set_gainceiling(s, (gainceiling_t)0);
  s->set_bpc(s, 0);
  s->set_wpc(s, 1);
  s->set_raw_gma(s, 1);
  s->set_lenc(s, 1);
  s->set_hmirror(s, 0);
  s->set_vflip(s, 0);
  s->set_dcw(s, 1);

  Serial.println("[OK] Camera initialised");
}

// ─── setup() ─────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  Serial.println("\n=============================");
  Serial.println(" AAR - Acquisition Node Boot");
  Serial.println("=============================");

  initCamera();

  // Connect to phone hotspot
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.printf("[WiFi] Connecting to '%s'", WIFI_SSID);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("\n[ERROR] WiFi connection failed. Check SSID/password.");
    Serial.println("        Restarting in 5 seconds...");
    delay(5000);
    ESP.restart();
  }

  Serial.println("\n[OK] WiFi connected!");
  Serial.print("[INFO] ESP32-CAM IP Address: ");
  Serial.println(WiFi.localIP());
  Serial.println("[INFO] Stream URL: http://" + WiFi.localIP().toString() + ":81/stream");
  Serial.println("[INFO] Enter this IP in the AAR mobile app.");

  startCameraServer();
  Serial.println("[OK] Acquisition Node ready. Streaming...\n");
}

// ─── loop() ──────────────────────────────────────────────────
void loop() {
  // Watchdog: reconnect if WiFi drops
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[WARN] WiFi lost. Reconnecting...");
    WiFi.reconnect();
    delay(5000);
  }
  delay(10000);
}
