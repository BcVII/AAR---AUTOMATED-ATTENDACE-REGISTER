"""
==============================================================
 AAR - Tabs 3–6: Records, Analytics, Export, Manage
==============================================================
"""

import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW
import datetime

from mobile_app.database.db_manager import (
    get_all_courses,
    get_todays_attendance,
    compute_attendance_percentages,
    get_session_history,
    get_all_students,
    add_course,
    delete_student,
    ELIGIBILITY_THRESHOLD,
)
from mobile_app.analytics.export_service import (
    export_daily_csv,
    export_semester_csv,
    export_daily_pdf,
    export_eligibility_pdf,
)


# ──────────────────────────────────────────────────────────────
#  Tab 3: Records
# ──────────────────────────────────────────────────────────────

class RecordsTab:
    def __init__(self, app):
        self.app = app

    def build(self) -> toga.Box:
        self._sel_course = toga.Selection(style=Pack(flex=1, padding=4))
        self._refresh_courses()

        btn_load = toga.Button("🔄  Load Today's Records",
                               on_press=self._load_records,
                               style=Pack(padding=6, flex=1))
        btn_history = toga.Button("📅  Session History",
                                  on_press=self._load_history,
                                  style=Pack(padding=6, flex=1))

        row_controls = toga.Box(
            children=[
                toga.Label("Course:", style=Pack(padding=(0, 4))),
                self._sel_course,
            ],
            style=Pack(direction=ROW, padding=4)
        )
        row_btns = toga.Box(
            children=[btn_load, btn_history],
            style=Pack(direction=ROW, padding=4)
        )

        self._lbl_info = toga.Label("Select a course and load records.", style=Pack(padding=6))

        self._table = toga.Table(
            headings=["SIN", "Name", "Time / Info"],
            data=[],
            style=Pack(flex=1, padding=4)
        )

        return toga.Box(
            children=[
                toga.Label("📋 Attendance Records", style=Pack(
                    padding=(8, 4, 4, 4), font_size=16, font_weight="bold"
                )),
                row_controls,
                row_btns,
                self._lbl_info,
                self._table,
            ],
            style=Pack(direction=COLUMN, padding=8, flex=1)
        )

    def _load_records(self, widget):
        course_id = self._get_course_id()
        if not course_id:
            return
        records = get_todays_attendance(course_id)
        self._table.data = [(r["sin"], r["name"], r["timestamp"][11:19]) for r in records]
        self._lbl_info.text = (
            f"Today ({datetime.date.today()}) – {len(records)} students present."
        )

    def _load_history(self, widget):
        course_id = self._get_course_id()
        if not course_id:
            return
        history = get_session_history(course_id)
        self._table.data = [(h["date"], f"{h['present_count']} present", "") for h in history]
        self._lbl_info.text = f"Session history for {course_id} – {len(history)} sessions total."

    def _get_course_id(self):
        item = self._sel_course.value
        if not item:
            self.app.main_window.error_dialog("No Course", "Select a course first.")
            return None
        return str(item).split("–")[0].strip()

    def _refresh_courses(self):
        courses = get_all_courses()
        items = [f"{c['course_id']} – {c['course_name']}" for c in courses]
        self._sel_course.items = items if items else ["No courses"]


# ──────────────────────────────────────────────────────────────
#  Tab 4: Analytics
# ──────────────────────────────────────────────────────────────

class AnalyticsTab:
    def __init__(self, app):
        self.app = app

    def build(self) -> toga.Box:
        self._sel_course = toga.Selection(style=Pack(flex=1, padding=4))
        self._refresh_courses()

        btn_compute = toga.Button(
            "📊  Compute Attendance %",
            on_press=self._compute,
            style=Pack(padding=6)
        )

        self._lbl_summary = toga.Label(
            f"Eligibility threshold: {ELIGIBILITY_THRESHOLD:.0f}%  (CBU Policy)",
            style=Pack(padding=6, font_size=10)
        )

        self._table = toga.Table(
            headings=["SIN", "Name", "Attended", "Total", "Pct %", "Status"],
            data=[],
            style=Pack(flex=1, padding=4)
        )

        row_course = toga.Box(
            children=[toga.Label("Course:", style=Pack(padding=(0, 4))), self._sel_course],
            style=Pack(direction=ROW, padding=4)
        )

        return toga.Box(
            children=[
                toga.Label("📊 Attendance Analytics", style=Pack(
                    padding=(8, 4, 4, 4), font_size=16, font_weight="bold"
                )),
                row_course,
                btn_compute,
                self._lbl_summary,
                self._table,
            ],
            style=Pack(direction=COLUMN, padding=8, flex=1)
        )

    def _compute(self, widget):
        item = self._sel_course.value
        if not item:
            return
        course_id = str(item).split("–")[0].strip()
        results = compute_attendance_percentages(course_id)

        rows = []
        eligible_count = 0
        for r in results:
            rows.append((
                r["sin"], r["name"],
                str(r["sessions_attended"]), str(r["total_sessions"]),
                f"{r['attendance_pct']}%", r["status"]
            ))
            if r["eligible"]:
                eligible_count += 1

        self._table.data = rows
        at_risk = len(results) - eligible_count
        self._lbl_summary.text = (
            f"Threshold: {ELIGIBILITY_THRESHOLD:.0f}%  |  "
            f"Eligible: {eligible_count}  |  At Risk: {at_risk}  |  Total: {len(results)}"
        )

    def _refresh_courses(self):
        courses = get_all_courses()
        items = [f"{c['course_id']} – {c['course_name']}" for c in courses]
        self._sel_course.items = items if items else ["No courses"]


# ──────────────────────────────────────────────────────────────
#  Tab 5: Export
# ──────────────────────────────────────────────────────────────

class ExportTab:
    def __init__(self, app):
        self.app = app

    def build(self) -> toga.Box:
        self._sel_course = toga.Selection(style=Pack(flex=1, padding=4))
        self._refresh_courses()

        row_course = toga.Box(
            children=[toga.Label("Course:", style=Pack(padding=(0, 4))), self._sel_course],
            style=Pack(direction=ROW, padding=4)
        )

        self._lbl_result = toga.Label("Select a course and choose an export format.",
                                       style=Pack(padding=6, font_size=10))

        def make_btn(label, handler):
            return toga.Button(label, on_press=handler, style=Pack(padding=6, flex=1))

        row1 = toga.Box(children=[
            make_btn("📄 Daily CSV",         self._exp_daily_csv),
            make_btn("📄 Semester CSV",       self._exp_sem_csv),
        ], style=Pack(direction=ROW, padding=4))

        row2 = toga.Box(children=[
            make_btn("📑 Daily PDF",          self._exp_daily_pdf),
            make_btn("📑 Eligibility Report", self._exp_elig_pdf),
        ], style=Pack(direction=ROW, padding=4))

        return toga.Box(
            children=[
                toga.Label("📤 Export Reports", style=Pack(
                    padding=(8, 4, 4, 4), font_size=16, font_weight="bold"
                )),
                row_course,
                toga.Label("Daily exports are for today's session. Semester exports cover all sessions.",
                           style=Pack(padding=(2, 6), font_size=10)),
                toga.Divider(),
                row1,
                row2,
                self._lbl_result,
            ],
            style=Pack(direction=COLUMN, padding=8, flex=1)
        )

    def _get_course(self):
        item = self._sel_course.value
        if not item:
            self.app.main_window.error_dialog("No Course", "Select a course first.")
            return None
        return str(item).split("–")[0].strip()

    def _exp_daily_csv(self, w):
        cid = self._get_course()
        if cid:
            path = export_daily_csv(cid)
            self._lbl_result.text = f"✅ Saved: {path}"

    def _exp_sem_csv(self, w):
        cid = self._get_course()
        if cid:
            path = export_semester_csv(cid)
            self._lbl_result.text = f"✅ Saved: {path}"

    def _exp_daily_pdf(self, w):
        cid = self._get_course()
        if cid:
            path = export_daily_pdf(cid)
            self._lbl_result.text = f"✅ Saved: {path}"

    def _exp_elig_pdf(self, w):
        cid = self._get_course()
        if cid:
            path = export_eligibility_pdf(cid)
            self._lbl_result.text = f"✅ Saved: {path}"

    def _refresh_courses(self):
        courses = get_all_courses()
        items = [f"{c['course_id']} – {c['course_name']}" for c in courses]
        self._sel_course.items = items if items else ["No courses"]


# ──────────────────────────────────────────────────────────────
#  Tab 6: Manage (Courses + Students)
# ──────────────────────────────────────────────────────────────

class ManageTab:
    def __init__(self, app):
        self.app = app

    def build(self) -> toga.Box:
        # ── Add Course ────────────────────────────────────────
        self._inp_cid   = toga.TextInput(placeholder="Course ID (e.g. CEE401)", style=Pack(flex=1, padding=4))
        self._inp_cname = toga.TextInput(placeholder="Course Name", style=Pack(flex=1, padding=4))
        btn_add_course  = toga.Button("➕ Add Course", on_press=self._add_course,
                                      style=Pack(padding=6))

        row_cid = toga.Box(
            children=[toga.Label("ID:", style=Pack(width=30, padding=(0, 4))), self._inp_cid],
            style=Pack(direction=ROW, padding=4)
        )
        row_cname = toga.Box(
            children=[toga.Label("Name:", style=Pack(width=50, padding=(0, 4))), self._inp_cname],
            style=Pack(direction=ROW, padding=4)
        )

        # ── Student Removal ───────────────────────────────────
        self._sel_course_del = toga.Selection(style=Pack(flex=1, padding=4))
        self._inp_del_sin = toga.TextInput(placeholder="SIN to remove", style=Pack(flex=1, padding=4))
        btn_del_student = toga.Button("🗑  Remove Student", on_press=self._delete_student,
                                      style=Pack(padding=6, background_color="#8b0000", color="white"))

        row_del = toga.Box(
            children=[
                toga.Label("Course:", style=Pack(width=60, padding=(0, 4))),
                self._sel_course_del,
            ],
            style=Pack(direction=ROW, padding=4)
        )
        row_del2 = toga.Box(
            children=[toga.Label("SIN:", style=Pack(width=60, padding=(0, 4))), self._inp_del_sin],
            style=Pack(direction=ROW, padding=4)
        )

        # ── Course list display ───────────────────────────────
        self._course_table = toga.Table(
            headings=["Course ID", "Course Name"],
            data=[],
            style=Pack(flex=1, padding=4)
        )
        btn_refresh = toga.Button("🔄 Refresh", on_press=self._refresh_all,
                                  style=Pack(padding=6))

        self._lbl_manage_status = toga.Label("", style=Pack(padding=6))

        self._refresh_all(None)

        return toga.Box(
            children=[
                toga.Label("⚙️ Manage", style=Pack(
                    padding=(8, 4, 4, 4), font_size=16, font_weight="bold"
                )),
                toga.Label("── Add Course ──", style=Pack(padding=(6, 4, 2, 4), font_weight="bold")),
                row_cid,
                row_cname,
                btn_add_course,
                toga.Divider(),
                toga.Label("── Remove Student ──", style=Pack(padding=(6, 4, 2, 4), font_weight="bold")),
                row_del,
                row_del2,
                btn_del_student,
                toga.Divider(),
                self._lbl_manage_status,
                toga.Label("Courses:", style=Pack(padding=(4, 6))),
                btn_refresh,
                self._course_table,
            ],
            style=Pack(direction=COLUMN, padding=8, flex=1)
        )

    def _add_course(self, widget):
        cid   = self._inp_cid.value.strip()
        cname = self._inp_cname.value.strip()
        if not cid or not cname:
            self.app.main_window.error_dialog("Input Error", "Course ID and Name required.")
            return
        ok = add_course(cid, cname)
        if ok:
            self._lbl_manage_status.text = f"✅ Course {cid} added."
            self._inp_cid.value = ""
            self._inp_cname.value = ""
            self._refresh_all(None)
        else:
            self._lbl_manage_status.text = f"⚠️ Course {cid} already exists."

    def _delete_student(self, widget):
        sin = self._inp_del_sin.value.strip()
        item = self._sel_course_del.value
        if not sin or not item:
            self.app.main_window.error_dialog("Input Error", "Select course and enter SIN.")
            return
        course_id = str(item).split("–")[0].strip()
        delete_student(sin, course_id)
        self._lbl_manage_status.text = f"✅ Student {sin} removed from {course_id}."
        self._inp_del_sin.value = ""

    def _refresh_all(self, widget):
        courses = get_all_courses()
        self._course_table.data = [(c["course_id"], c["course_name"]) for c in courses]
        items = [f"{c['course_id']} – {c['course_name']}" for c in courses]
        self._sel_course_del.items = items if items else ["No courses"]
        if widget is not None:
            self._lbl_manage_status.text = "Refreshed."
