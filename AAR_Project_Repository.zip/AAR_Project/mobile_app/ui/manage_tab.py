from mobile_app.ui.records_tab import ManageTab
__all__ = ["ManageTab"]
