"""
==============================================================
 AAR - Tab 1: Live Attendance
 Dynamic Connection Manager + Real-time Attendance Monitoring
 (SDS 3.3.2 Layer I - Interface Layer)
==============================================================
"""

import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW
import threading

from mobile_app.recognition.stream_service import StreamService
from mobile_app.database.db_manager import get_all_courses, get_todays_attendance


class AttendanceTab:
    def __init__(self, app: toga.App):
        self.app = app
        self._service = StreamService()
        self._setup_callbacks()
        self._present_count = 0

    def _setup_callbacks(self):
        self._service.on_student_recognised = self._on_student_recognised
        self._service.on_error = self._on_error
        self._service.on_session_closed = self._on_session_closed
        self._service.on_status_update = self._on_status_update

    def build(self) -> toga.Box:
        """Build the Attendance tab layout."""
        # ── Connection Panel ──────────────────────────────────
        lbl_ip = toga.Label("ESP32-CAM IP Address:", style=Pack(padding=(0, 4)))
        self._inp_ip = toga.TextInput(
            placeholder="e.g. 192.168.43.10",
            style=Pack(flex=1, padding=4)
        )

        lbl_course = toga.Label("Course:", style=Pack(padding=(0, 4)))
        self._sel_course = toga.Selection(style=Pack(flex=1, padding=4))
        self._refresh_course_list()

        row_ip = toga.Box(
            children=[lbl_ip, self._inp_ip],
            style=Pack(direction=ROW, padding=4)
        )
        row_course = toga.Box(
            children=[lbl_course, self._sel_course],
            style=Pack(direction=ROW, padding=4)
        )

        # ── Control Buttons ───────────────────────────────────
        self._btn_start = toga.Button(
            "▶  Start Session",
            on_press=self._on_start,
            style=Pack(padding=6, background_color="#1a5f2a", color="white", flex=1)
        )
        self._btn_stop = toga.Button(
            "⏹  Stop Session",
            on_press=self._on_stop,
            style=Pack(padding=6, background_color="#8b0000", color="white", flex=1),
            enabled=False
        )
        row_btns = toga.Box(
            children=[self._btn_start, self._btn_stop],
            style=Pack(direction=ROW, padding=4)
        )

        # ── Status Label ──────────────────────────────────────
        self._lbl_status = toga.Label(
            "Status: Ready. Enter ESP32-CAM IP and select course.",
            style=Pack(padding=6, font_size=11)
        )

        # ── Timer Label ───────────────────────────────────────
        self._lbl_timer = toga.Label(
            "Attendance window: 15:00 remaining",
            style=Pack(padding=(2, 6), font_size=10)
        )

        # ── Present Count ─────────────────────────────────────
        self._lbl_count = toga.Label(
            "Students marked present: 0",
            style=Pack(padding=(2, 6), font_size=12, font_weight="bold")
        )

        # ── Attendance Table ──────────────────────────────────
        self._table = toga.Table(
            headings=["SIN", "Name", "Time"],
            data=[],
            style=Pack(flex=1, padding=4)
        )

        # ── Main Layout ───────────────────────────────────────
        return toga.Box(
            children=[
                toga.Label("📷 Live Attendance", style=Pack(
                    padding=(8, 4, 4, 4), font_size=16, font_weight="bold"
                )),
                row_ip,
                row_course,
                row_btns,
                self._lbl_status,
                self._lbl_timer,
                self._lbl_count,
                toga.Divider(),
                toga.Label("Present Students:", style=Pack(padding=(4, 6))),
                self._table,
            ],
            style=Pack(direction=COLUMN, padding=8, flex=1)
        )

    # ─────────────────────────────────────────────────────────
    #  Button Handlers
    # ─────────────────────────────────────────────────────────

    def _on_start(self, widget):
        ip = self._inp_ip.value.strip()
        if not ip:
            self.app.main_window.error_dialog("Input Error", "Please enter the ESP32-CAM IP address.")
            return

        course_item = self._sel_course.value
        if not course_item:
            self.app.main_window.error_dialog("Input Error", "Please select a course.")
            return

        # course_item is a string "ID – Name"
        course_id = str(course_item).split("–")[0].strip()

        self._present_count = 0
        self._table.data = []

        started = self._service.start_session(ip, course_id)
        if started:
            self._btn_start.enabled = False
            self._btn_stop.enabled = True
            self._start_timer_update()

    def _on_stop(self, widget):
        self._service.stop_session()
        self._btn_start.enabled = True
        self._btn_stop.enabled = False

    # ─────────────────────────────────────────────────────────
    #  Service Callbacks (called from background thread)
    # ─────────────────────────────────────────────────────────

    def _on_student_recognised(self, sin: str, name: str, score: float):
        """Called when a student is successfully identified and logged."""
        def update():
            import datetime
            time_str = datetime.datetime.now().strftime("%H:%M:%S")
            self._table.data.append((sin, name, time_str))
            self._present_count += 1
            self._lbl_count.text = f"Students marked present: {self._present_count}"
            self._lbl_status.text = f"✅ Marked present: {name} (confidence: {score:.2f})"

        self.app.add_background_task(lambda _: update())

    def _on_error(self, msg: str):
        def show():
            self._lbl_status.text = f"❌ Error: {msg}"
            self._btn_start.enabled = True
            self._btn_stop.enabled = False

        self.app.add_background_task(lambda _: show())

    def _on_session_closed(self):
        def update():
            self._lbl_status.text = "Session closed. Attendance window ended."
            self._btn_start.enabled = True
            self._btn_stop.enabled = False
            self._lbl_timer.text = "Attendance window: CLOSED (105-min lockout active)"

        self.app.add_background_task(lambda _: update())

    def _on_status_update(self, msg: str):
        def update():
            self._lbl_status.text = f"ℹ️ {msg}"

        self.app.add_background_task(lambda _: update())

    # ─────────────────────────────────────────────────────────
    #  Timer Display Updater
    # ─────────────────────────────────────────────────────────

    def _start_timer_update(self):
        """Update the countdown timer every second in a background thread."""
        def _tick():
            import time
            while self._service.is_streaming:
                remaining = self._service.session_time_remaining
                mins = int(remaining // 60)
                secs = int(remaining % 60)

                def update_label(_, m=mins, s=secs):
                    self._lbl_timer.text = f"Attendance window: {m:02d}:{s:02d} remaining"

                self.app.add_background_task(update_label)
                time.sleep(1)

        threading.Thread(target=_tick, daemon=True).start()

    # ─────────────────────────────────────────────────────────
    #  Helpers
    # ─────────────────────────────────────────────────────────

    def _refresh_course_list(self):
        """Populate the course dropdown."""
        courses = get_all_courses()
        items = [f"{c['course_id']} – {c['course_name']}" for c in courses]
        self._sel_course.items = items if items else ["No courses – add in Manage tab"]
