"""
==============================================================
 AAR - Interface Layer (Presentation Layer)
 SDS Section 3.3.2 - Layer I (Interface Layer / Toga)
==============================================================
 Implements the Interface Layer described in SDS using the
 BeeWare/Toga framework (confirmed in SDS 3.3.2, Layer I).

 Tabs:
   1. Live Attendance  – connect to ESP32, start session
   2. Register Student – capture face + enrol student
   3. View Records     – browse today's / historical attendance
   4. Analytics        – attendance percentages, eligibility flags
   5. Export           – PDF / CSV generation
   6. Manage           – courses, student management
==============================================================
"""

import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW
import threading

from mobile_app.database.db_manager import initialise_database
from mobile_app.ui.attendance_tab import AttendanceTab
from mobile_app.ui.register_tab import RegisterTab
from mobile_app.ui.records_tab import RecordsTab
from mobile_app.ui.analytics_tab import AnalyticsTab
from mobile_app.ui.export_tab import ExportTab
from mobile_app.ui.manage_tab import ManageTab


class AARApp(toga.App):
    """
    Root application class.
    Initialises the database on startup and builds the tabbed UI.
    """

    def startup(self):
        # ── Initialise DB on first run ────────────────────────
        try:
            initialise_database()
        except Exception as e:
            print(f"[App] DB init error: {e}")

        # ── Build tabbed main window ──────────────────────────
        self.main_window = toga.MainWindow(title="AAR – Automated Attendance Register")

        # Instantiate each tab
        self._attendance_tab = AttendanceTab(self)
        self._register_tab   = RegisterTab(self)
        self._records_tab    = RecordsTab(self)
        self._analytics_tab  = AnalyticsTab(self)
        self._export_tab     = ExportTab(self)
        self._manage_tab     = ManageTab(self)

        # Build OptionContainer (tabbed layout)
        tab_container = toga.OptionContainer(
            content=[
                toga.OptionItem("📷 Attendance", self._attendance_tab.build()),
                toga.OptionItem("➕ Register",   self._register_tab.build()),
                toga.OptionItem("📋 Records",    self._records_tab.build()),
                toga.OptionItem("📊 Analytics",  self._analytics_tab.build()),
                toga.OptionItem("📤 Export",     self._export_tab.build()),
                toga.OptionItem("⚙️ Manage",     self._manage_tab.build()),
            ],
            style=Pack(flex=1)
        )

        self.main_window.content = tab_container
        self.main_window.show()
