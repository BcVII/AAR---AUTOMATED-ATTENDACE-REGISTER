"""
==============================================================
 AAR - Tab 2: Register New Student
 SDS 2.4: Student Registration – capture face + enrol
 SDS 3.3.2 Layer I: "New Member" sequence
==============================================================
 Captures a face from the ESP32-CAM stream (or webcam during
 development) and stores the 512-dim embedding in the DB.
==============================================================
"""

import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW
import threading
import numpy as np
from typing import Optional

from mobile_app.database.db_manager import (
    register_student,
    get_all_courses,
    update_student_vector,
)
from mobile_app.recognition.recognition_engine import (
    load_models,
    decode_jpeg_frame,
    extract_embedding,
    frame_to_jpeg_bytes,
)
import requests


class RegisterTab:
    def __init__(self, app: toga.App):
        self.app = app
        self._captured_embedding: Optional[np.ndarray] = None
        self._capture_preview: Optional[bytes] = None

    def build(self) -> toga.Box:
        # ── Course selection ──────────────────────────────────
        self._sel_course = toga.Selection(style=Pack(flex=1, padding=4))
        self._refresh_courses()

        row_course = toga.Box(
            children=[toga.Label("Course:", style=Pack(padding=(0, 4))), self._sel_course],
            style=Pack(direction=ROW, padding=4)
        )

        # ── Student details ───────────────────────────────────
        self._inp_sin = toga.TextInput(placeholder="Student ID (e.g. 23133136)", style=Pack(flex=1, padding=4))
        self._inp_name = toga.TextInput(placeholder="Full Name", style=Pack(flex=1, padding=4))
        self._inp_programme = toga.TextInput(placeholder="Programme (e.g. Computer Engineering)", style=Pack(flex=1, padding=4))

        row_sin = toga.Box(
            children=[toga.Label("SIN:", style=Pack(padding=(0, 4), width=90)), self._inp_sin],
            style=Pack(direction=ROW, padding=4)
        )
        row_name = toga.Box(
            children=[toga.Label("Name:", style=Pack(padding=(0, 4), width=90)), self._inp_name],
            style=Pack(direction=ROW, padding=4)
        )
        row_prog = toga.Box(
            children=[toga.Label("Programme:", style=Pack(padding=(0, 4), width=90)), self._inp_programme],
            style=Pack(direction=ROW, padding=4)
        )

        # ── ESP32 IP for capture ──────────────────────────────
        self._inp_ip = toga.TextInput(placeholder="ESP32-CAM IP (e.g. 192.168.43.10)", style=Pack(flex=1, padding=4))
        row_ip = toga.Box(
            children=[toga.Label("Camera IP:", style=Pack(padding=(0, 4), width=90)), self._inp_ip],
            style=Pack(direction=ROW, padding=4)
        )

        # ── Capture button ────────────────────────────────────
        self._btn_capture = toga.Button(
            "📸  Capture Face",
            on_press=self._on_capture,
            style=Pack(padding=6, flex=1)
        )
        self._btn_register = toga.Button(
            "💾  Register Student",
            on_press=self._on_register,
            style=Pack(padding=6, flex=1),
            enabled=False
        )
        row_btns = toga.Box(
            children=[self._btn_capture, self._btn_register],
            style=Pack(direction=ROW, padding=4)
        )

        # ── Status and preview ────────────────────────────────
        self._lbl_status = toga.Label(
            "Step 1: Fill in student details. Step 2: Capture face. Step 3: Register.",
            style=Pack(padding=6, font_size=10)
        )
        self._lbl_face_status = toga.Label(
            "Face: Not captured",
            style=Pack(padding=(2, 6), font_size=11)
        )

        return toga.Box(
            children=[
                toga.Label("➕ Register New Student", style=Pack(
                    padding=(8, 4, 4, 4), font_size=16, font_weight="bold"
                )),
                row_course,
                row_sin,
                row_name,
                row_prog,
                toga.Divider(),
                row_ip,
                row_btns,
                self._lbl_face_status,
                self._lbl_status,
            ],
            style=Pack(direction=COLUMN, padding=8, flex=1)
        )

    # ─────────────────────────────────────────────────────────
    #  Face Capture
    # ─────────────────────────────────────────────────────────

    def _on_capture(self, widget):
        """Grab a frame from ESP32-CAM and extract the face embedding."""
        ip = self._inp_ip.value.strip()
        if not ip:
            self.app.main_window.error_dialog("Input Error", "Enter ESP32-CAM IP address.")
            return

        self._lbl_status.text = "Capturing from camera... hold still."

        def _capture():
            try:
                load_models()
                # Grab a single JPEG frame from the stream
                stream_url = f"http://{ip}:81/stream"
                response = requests.get(stream_url, stream=True, timeout=8)

                jpeg_bytes = None
                buffer = b""
                for chunk in response.iter_content(chunk_size=4096):
                    buffer += chunk
                    start = buffer.find(b"\xff\xd8")
                    end   = buffer.find(b"\xff\xd9")
                    if start != -1 and end != -1 and end > start:
                        jpeg_bytes = buffer[start:end + 2]
                        break

                response.close()

                if jpeg_bytes is None:
                    self._set_status("❌ Could not grab frame. Check camera connection.")
                    return

                frame = decode_jpeg_frame(jpeg_bytes)
                if frame is None:
                    self._set_status("❌ Frame decode failed.")
                    return

                embedding = extract_embedding(frame)
                if embedding is None:
                    self._set_status("❌ No face detected. Ensure student faces the camera.")
                    return

                self._captured_embedding = embedding
                self._set_status("✅ Face captured successfully! Click 'Register Student'.")
                self._set_face_status("Face: ✅ CAPTURED (512-dim vector ready)")
                self.app.add_background_task(lambda _: setattr(self._btn_register, "enabled", True))

            except Exception as e:
                self._set_status(f"❌ Capture error: {e}")

        threading.Thread(target=_capture, daemon=True).start()

    # ─────────────────────────────────────────────────────────
    #  Student Registration
    # ─────────────────────────────────────────────────────────

    def _on_register(self, widget):
        sin       = self._inp_sin.value.strip()
        name      = self._inp_name.value.strip()
        programme = self._inp_programme.value.strip()

        if not sin or not name:
            self.app.main_window.error_dialog("Input Error", "SIN and Name are required.")
            return

        if self._captured_embedding is None:
            self.app.main_window.error_dialog("No Face", "Please capture the student's face first.")
            return

        course_item = self._sel_course.value
        if not course_item:
            self.app.main_window.error_dialog("No Course", "Please select a course.")
            return

        course_id = str(course_item).split("–")[0].strip()

        success = register_student(sin, course_id, name, programme, self._captured_embedding)

        if success:
            self._lbl_status.text = f"✅ {name} ({sin}) registered successfully!"
            self._lbl_face_status.text = "Face: Not captured"
            self._captured_embedding = None
            self._btn_register.enabled = False
            self._inp_sin.value = ""
            self._inp_name.value = ""
            self._inp_programme.value = ""
        else:
            # Already registered – offer to update vector
            self.app.main_window.confirm_dialog(
                "Already Registered",
                f"{sin} is already registered for {course_id}. Update their face data?",
            ).add_done_callback(
                lambda result: self._update_if_confirmed(result, sin, course_id)
            )

    def _update_if_confirmed(self, result, sin, course_id):
        if result and self._captured_embedding is not None:
            update_student_vector(sin, course_id, self._captured_embedding)
            self._lbl_status.text = f"✅ Face data updated for {sin}."

    # ─────────────────────────────────────────────────────────
    #  Helpers
    # ─────────────────────────────────────────────────────────

    def _set_status(self, msg: str):
        self.app.add_background_task(lambda _: setattr(self._lbl_status, "text", msg))

    def _set_face_status(self, msg: str):
        self.app.add_background_task(lambda _: setattr(self._lbl_face_status, "text", msg))

    def _refresh_courses(self):
        courses = get_all_courses()
        items = [f"{c['course_id']} – {c['course_name']}" for c in courses]
        self._sel_course.items = items if items else ["No courses – add in Manage tab"]
