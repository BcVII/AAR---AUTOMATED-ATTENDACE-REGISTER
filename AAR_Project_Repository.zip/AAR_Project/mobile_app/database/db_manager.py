"""
==============================================================
 AAR - Persistence Node (SDS Section 3.3.2 - Layer IV)
 SQLite3 Database Manager
==============================================================
 Implements the Sparse Logging Strategy described in SDS 3.3.4:
   - Master Register: all enrolled students + face vectors
   - Course List:     course registry
   - Log Register:    PRESENT-ONLY daily attendance logs

 Schema (from SDS Figure 6):
   courses(course_id, course_name)
   students(sin, course_id, name, programme, vector_blob, attendance_pct)
   attendance_logs(log_id, course_id, sin, name, timestamp)
==============================================================
"""

import sqlite3
import os
import json
import datetime
import numpy as np
from typing import Optional, List, Tuple

DB_PATH = os.path.join(os.path.dirname(__file__), "aar_database.db")


def get_connection() -> sqlite3.Connection:
    """Return a connection to the SQLite database."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Allow column-name access
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def initialise_database() -> None:
    """
    Create all tables on first run.
    Safe to call multiple times (uses IF NOT EXISTS).
    """
    conn = get_connection()
    cursor = conn.cursor()

    # ── Table 1: Courses ─────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS courses (
            course_id   TEXT PRIMARY KEY,
            course_name TEXT NOT NULL
        )
    """)

    # ── Table 2: Master Student Register ─────────────────────
    # vector_blob stores the 512-dim float32 numpy array as bytes
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            sin                 TEXT    NOT NULL,
            course_id           TEXT    NOT NULL,
            name                TEXT    NOT NULL,
            programme           TEXT    NOT NULL DEFAULT '',
            vector_blob         BLOB,
            attendance_pct      REAL    DEFAULT 0.0,
            PRIMARY KEY (sin, course_id),
            FOREIGN KEY (course_id) REFERENCES courses(course_id)
        )
    """)

    # ── Table 3: Daily Attendance Log (Present-Only) ─────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance_logs (
            log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id   TEXT    NOT NULL,
            sin         TEXT    NOT NULL,
            name        TEXT    NOT NULL,
            timestamp   TEXT    NOT NULL,
            session_date TEXT   NOT NULL,
            FOREIGN KEY (course_id) REFERENCES courses(course_id)
        )
    """)

    # ── Table 4: Session Registry ────────────────────────────
    # Tracks each session opened so we can compute total sessions
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            session_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id       TEXT    NOT NULL,
            session_date    TEXT    NOT NULL,
            UNIQUE(course_id, session_date),
            FOREIGN KEY (course_id) REFERENCES courses(course_id)
        )
    """)

    conn.commit()
    conn.close()
    print("[DB] Database initialised.")


# ─────────────────────────────────────────────────────────────
#  COURSE OPERATIONS
# ─────────────────────────────────────────────────────────────

def add_course(course_id: str, course_name: str) -> bool:
    """Add a new course. Returns True on success."""
    try:
        conn = get_connection()
        conn.execute(
            "INSERT INTO courses (course_id, course_name) VALUES (?, ?)",
            (course_id.upper().strip(), course_name.strip())
        )
        conn.commit()
        conn.close()
        return True
    except sqlite3.IntegrityError:
        return False  # Already exists


def get_all_courses() -> List[dict]:
    """Return list of all courses."""
    conn = get_connection()
    rows = conn.execute("SELECT * FROM courses ORDER BY course_name").fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ─────────────────────────────────────────────────────────────
#  STUDENT OPERATIONS
# ─────────────────────────────────────────────────────────────

def register_student(
    sin: str,
    course_id: str,
    name: str,
    programme: str,
    face_vector: Optional[np.ndarray]
) -> bool:
    """
    Register a new student with their face vector.
    Stores the 512-dim vector as a binary blob (efficient, private).
    Returns True on success, False if already registered.
    """
    vector_blob = None
    if face_vector is not None:
        vector_blob = face_vector.astype(np.float32).tobytes()

    try:
        conn = get_connection()
        conn.execute(
            """INSERT INTO students (sin, course_id, name, programme, vector_blob)
               VALUES (?, ?, ?, ?, ?)""",
            (sin.strip(), course_id.upper().strip(), name.strip(), programme.strip(), vector_blob)
        )
        conn.commit()
        conn.close()
        return True
    except sqlite3.IntegrityError:
        return False


def update_student_vector(sin: str, course_id: str, face_vector: np.ndarray) -> None:
    """Update the stored face embedding for a student (re-registration)."""
    blob = face_vector.astype(np.float32).tobytes()
    conn = get_connection()
    conn.execute(
        "UPDATE students SET vector_blob = ? WHERE sin = ? AND course_id = ?",
        (blob, sin, course_id.upper())
    )
    conn.commit()
    conn.close()


def delete_student(sin: str, course_id: str) -> None:
    """Remove a student from the register (SDS 2.4 Student Management)."""
    conn = get_connection()
    conn.execute("DELETE FROM students WHERE sin = ? AND course_id = ?",
                 (sin, course_id.upper()))
    conn.commit()
    conn.close()


def get_all_students(course_id: str) -> List[dict]:
    """Return all students enrolled in a course, with their face vectors loaded."""
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM students WHERE course_id = ? ORDER BY name",
        (course_id.upper(),)
    ).fetchall()
    conn.close()

    students = []
    for row in rows:
        s = dict(row)
        if s["vector_blob"]:
            s["vector"] = np.frombuffer(s["vector_blob"], dtype=np.float32)
        else:
            s["vector"] = None
        del s["vector_blob"]  # Don't expose raw blob
        students.append(s)
    return students


def get_registered_vectors(course_id: str) -> List[Tuple[str, str, np.ndarray]]:
    """
    Returns list of (sin, name, vector) tuples for face matching.
    Only includes students WITH a registered face vector.
    """
    conn = get_connection()
    rows = conn.execute(
        "SELECT sin, name, vector_blob FROM students WHERE course_id = ? AND vector_blob IS NOT NULL",
        (course_id.upper(),)
    ).fetchall()
    conn.close()

    result = []
    for row in rows:
        vec = np.frombuffer(row["vector_blob"], dtype=np.float32)
        result.append((row["sin"], row["name"], vec))
    return result


# ─────────────────────────────────────────────────────────────
#  ATTENDANCE LOGGING (SDS 3.3.4 - Sparse Logging)
# ─────────────────────────────────────────────────────────────

def open_session(course_id: str) -> str:
    """
    Register a new attendance session for today.
    Returns the session_date string. Idempotent (safe to call multiple times).
    """
    today = datetime.date.today().isoformat()
    conn = get_connection()
    conn.execute(
        "INSERT OR IGNORE INTO sessions (course_id, session_date) VALUES (?, ?)",
        (course_id.upper(), today)
    )
    conn.commit()
    conn.close()
    return today


def mark_present(course_id: str, sin: str, name: str) -> bool:
    """
    Mark a student PRESENT for today's session.
    Implements Duplicate Prevention (SDS 2.4): returns False if already marked.
    This is the atomic transaction commit described in SDS 3.2.2.
    """
    today = datetime.date.today().isoformat()
    timestamp = datetime.datetime.now().isoformat(timespec="seconds")

    conn = get_connection()

    # Duplicate check
    existing = conn.execute(
        """SELECT log_id FROM attendance_logs
           WHERE course_id = ? AND sin = ? AND session_date = ?""",
        (course_id.upper(), sin, today)
    ).fetchone()

    if existing:
        conn.close()
        return False  # Already marked

    conn.execute(
        """INSERT INTO attendance_logs (course_id, sin, name, timestamp, session_date)
           VALUES (?, ?, ?, ?, ?)""",
        (course_id.upper(), sin, name, timestamp, today)
    )
    conn.commit()
    conn.close()
    return True


def get_todays_attendance(course_id: str) -> List[dict]:
    """Return all students marked present today for a course."""
    today = datetime.date.today().isoformat()
    conn = get_connection()
    rows = conn.execute(
        """SELECT sin, name, timestamp FROM attendance_logs
           WHERE course_id = ? AND session_date = ?
           ORDER BY timestamp""",
        (course_id.upper(), today)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def is_already_marked(course_id: str, sin: str) -> bool:
    """Check if a student has already been marked present today."""
    today = datetime.date.today().isoformat()
    conn = get_connection()
    row = conn.execute(
        "SELECT 1 FROM attendance_logs WHERE course_id = ? AND sin = ? AND session_date = ?",
        (course_id.upper(), sin, today)
    ).fetchone()
    conn.close()
    return row is not None


# ─────────────────────────────────────────────────────────────
#  ANALYTICS (SDS 3.3.2 - Analytics Layer)
# ─────────────────────────────────────────────────────────────

ELIGIBILITY_THRESHOLD = 80.0  # CBU policy: 80% required (SDS Section 3.3.2 III)


def compute_attendance_percentages(course_id: str) -> List[dict]:
    """
    Compute attendance % for all students in a course.
    Formula from SDS:  (sessions attended / total sessions) * 100
    Also flags students below the 80% threshold.
    Returns list of dicts with analytics data.
    """
    conn = get_connection()

    total_sessions = conn.execute(
        "SELECT COUNT(*) as cnt FROM sessions WHERE course_id = ?",
        (course_id.upper(),)
    ).fetchone()["cnt"]

    if total_sessions == 0:
        conn.close()
        return []

    students = conn.execute(
        "SELECT sin, name FROM students WHERE course_id = ?",
        (course_id.upper(),)
    ).fetchall()

    results = []
    for student in students:
        sin = student["sin"]
        attended = conn.execute(
            "SELECT COUNT(*) as cnt FROM attendance_logs WHERE course_id = ? AND sin = ?",
            (course_id.upper(), sin)
        ).fetchone()["cnt"]

        pct = round((attended / total_sessions) * 100, 1)

        # Update stored percentage
        conn.execute(
            "UPDATE students SET attendance_pct = ? WHERE sin = ? AND course_id = ?",
            (pct, sin, course_id.upper())
        )

        results.append({
            "sin": sin,
            "name": student["name"],
            "sessions_attended": attended,
            "total_sessions": total_sessions,
            "attendance_pct": pct,
            "eligible": pct >= ELIGIBILITY_THRESHOLD,  # SDS 2.4 Eligibility Monitoring
            "status": "ELIGIBLE" if pct >= ELIGIBILITY_THRESHOLD else "AT RISK"
        })

    conn.commit()
    conn.close()

    # Sort: at-risk students first (most urgent)
    results.sort(key=lambda x: x["attendance_pct"])
    return results


def get_session_history(course_id: str) -> List[dict]:
    """Return all sessions and per-session attendance counts."""
    conn = get_connection()
    sessions = conn.execute(
        "SELECT session_date FROM sessions WHERE course_id = ? ORDER BY session_date",
        (course_id.upper(),)
    ).fetchall()

    result = []
    for s in sessions:
        date = s["session_date"]
        count = conn.execute(
            "SELECT COUNT(*) as cnt FROM attendance_logs WHERE course_id = ? AND session_date = ?",
            (course_id.upper(), date)
        ).fetchone()["cnt"]
        result.append({"date": date, "present_count": count})

    conn.close()
    return result


if __name__ == "__main__":
    # Quick DB initialisation test
    initialise_database()
    add_course("CEE401", "Computer Engineering Design IV")
    print("Courses:", get_all_courses())
    print("[DB] Self-test passed.")
