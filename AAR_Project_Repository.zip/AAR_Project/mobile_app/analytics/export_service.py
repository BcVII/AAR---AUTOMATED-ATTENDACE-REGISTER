"""
==============================================================
 AAR - Export Service
 SDS 2.4: Report Generation, Data Export, Attendance Analytics
==============================================================
 Generates:
   - CSV attendance reports (daily session or full semester)
   - PDF compliance reports (eligibility for exams, 80% threshold)
==============================================================
"""

import csv
import os
import datetime
from typing import List, Dict
from fpdf import FPDF

from mobile_app.database.db_manager import (
    get_todays_attendance,
    compute_attendance_percentages,
    get_session_history,
    get_all_students,
    get_all_courses,
    ELIGIBILITY_THRESHOLD,
)

EXPORT_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "exports")
os.makedirs(EXPORT_DIR, exist_ok=True)


def _timestamp_str() -> str:
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")


# ─────────────────────────────────────────────────────────────
#  CSV Export
# ─────────────────────────────────────────────────────────────

def export_daily_csv(course_id: str) -> str:
    """
    Export today's attendance log as CSV.
    Returns the file path.
    """
    records = get_todays_attendance(course_id)
    today = datetime.date.today().isoformat()
    filename = f"attendance_{course_id}_{today}.csv"
    filepath = os.path.join(EXPORT_DIR, filename)

    with open(filepath, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["SIN", "Name", "Time Marked", "Date", "Course ID"])
        for r in records:
            writer.writerow([r["sin"], r["name"], r["timestamp"], today, course_id])

    print(f"[Export] CSV saved: {filepath}")
    return filepath


def export_semester_csv(course_id: str) -> str:
    """
    Export full semester attendance percentages as CSV.
    Includes eligibility flag.
    """
    analytics = compute_attendance_percentages(course_id)
    filename = f"semester_report_{course_id}_{_timestamp_str()}.csv"
    filepath = os.path.join(EXPORT_DIR, filename)

    with open(filepath, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "SIN", "Name", "Sessions Attended",
            "Total Sessions", "Attendance %", "Status"
        ])
        for r in analytics:
            writer.writerow([
                r["sin"], r["name"], r["sessions_attended"],
                r["total_sessions"], r["attendance_pct"], r["status"]
            ])

    print(f"[Export] Semester CSV saved: {filepath}")
    return filepath


# ─────────────────────────────────────────────────────────────
#  PDF Export
# ─────────────────────────────────────────────────────────────

class _AARPDF(FPDF):
    """Custom PDF class with CBU-styled header and footer."""

    def __init__(self, course_id: str, report_title: str):
        super().__init__()
        self._course_id = course_id
        self._report_title = report_title

    def header(self):
        self.set_font("Helvetica", "B", 14)
        self.cell(0, 8, "COPPERBELT UNIVERSITY – SICT", align="C", ln=True)
        self.set_font("Helvetica", "B", 12)
        self.cell(0, 7, "Automated Attendance Register", align="C", ln=True)
        self.set_font("Helvetica", "", 10)
        self.cell(0, 6, f"Course: {self._course_id}   |   {self._report_title}", align="C", ln=True)
        self.cell(0, 5, f"Generated: {datetime.datetime.now().strftime('%d %B %Y, %H:%M')}", align="C", ln=True)
        self.ln(4)
        self.set_line_width(0.5)
        self.line(self.get_x(), self.get_y(), 200, self.get_y())
        self.ln(4)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.cell(0, 10, f"Page {self.page_no()} | AAR System – CBU Computer Engineering", align="C")


def export_daily_pdf(course_id: str) -> str:
    """
    Export today's attendance as a signed-off PDF.
    """
    records = get_todays_attendance(course_id)
    today = datetime.date.today().strftime("%d %B %Y")
    filename = f"daily_attendance_{course_id}_{_timestamp_str()}.pdf"
    filepath = os.path.join(EXPORT_DIR, filename)

    pdf = _AARPDF(course_id, f"Daily Attendance – {today}")
    pdf.add_page()
    pdf.set_font("Helvetica", "", 10)

    # Summary line
    pdf.set_font("Helvetica", "B", 10)
    pdf.cell(0, 7, f"Total Present: {len(records)}", ln=True)
    pdf.ln(3)

    # Table header
    col_widths = [40, 80, 60]
    headers = ["SIN", "Full Name", "Time Marked"]
    pdf.set_fill_color(30, 80, 160)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Helvetica", "B", 10)
    for i, h in enumerate(headers):
        pdf.cell(col_widths[i], 8, h, border=1, fill=True)
    pdf.ln()

    # Table rows
    pdf.set_text_color(0, 0, 0)
    pdf.set_font("Helvetica", "", 10)
    fill = False
    for r in records:
        pdf.set_fill_color(240, 245, 255) if fill else pdf.set_fill_color(255, 255, 255)
        time_str = r["timestamp"][11:19] if len(r["timestamp"]) > 10 else r["timestamp"]
        pdf.cell(col_widths[0], 7, r["sin"], border=1, fill=True)
        pdf.cell(col_widths[1], 7, r["name"], border=1, fill=True)
        pdf.cell(col_widths[2], 7, time_str, border=1, fill=True)
        pdf.ln()
        fill = not fill

    # Signature block
    pdf.ln(15)
    pdf.set_font("Helvetica", "", 10)
    pdf.cell(90, 6, "Class Representative Signature: ___________________")
    pdf.cell(90, 6, "Lecturer Signature: ___________________", ln=True)
    pdf.ln(3)
    pdf.cell(90, 6, "Name: ___________________")
    pdf.cell(90, 6, "Name: ___________________", ln=True)

    pdf.output(filepath)
    print(f"[Export] Daily PDF saved: {filepath}")
    return filepath


def export_eligibility_pdf(course_id: str) -> str:
    """
    Export full semester eligibility compliance report as PDF.
    Flags students below 80% threshold (SDS 2.4 Eligibility Monitoring).
    """
    analytics = compute_attendance_percentages(course_id)
    history = get_session_history(course_id)
    total_sessions = len(history)

    filename = f"eligibility_report_{course_id}_{_timestamp_str()}.pdf"
    filepath = os.path.join(EXPORT_DIR, filename)

    eligible_count = sum(1 for r in analytics if r["eligible"])
    at_risk_count = len(analytics) - eligible_count

    pdf = _AARPDF(course_id, "Semester Eligibility Report")
    pdf.add_page()

    # Summary box
    pdf.set_font("Helvetica", "B", 10)
    pdf.set_fill_color(240, 248, 240)
    pdf.cell(0, 8, f"Total Sessions Held: {total_sessions}   |   "
                   f"Enrolled Students: {len(analytics)}   |   "
                   f"Eligible: {eligible_count}   |   At Risk: {at_risk_count}",
             fill=True, ln=True)
    pdf.ln(4)

    pdf.set_font("Helvetica", "I", 9)
    pdf.cell(0, 6, f"Eligibility Threshold: {ELIGIBILITY_THRESHOLD:.0f}% (CBU Academic Regulation)", ln=True)
    pdf.ln(4)

    # Table
    col_widths = [38, 72, 25, 25, 25, 25]
    headers = ["SIN", "Full Name", "Present", "Sessions", "Pct %", "Status"]

    pdf.set_fill_color(30, 80, 160)
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Helvetica", "B", 9)
    for i, h in enumerate(headers):
        pdf.cell(col_widths[i], 8, h, border=1, fill=True)
    pdf.ln()

    pdf.set_text_color(0, 0, 0)
    pdf.set_font("Helvetica", "", 9)
    fill = False

    for r in analytics:
        if r["eligible"]:
            pdf.set_fill_color(235, 255, 235)  # Green tint for eligible
        else:
            pdf.set_fill_color(255, 235, 235)  # Red tint for at-risk

        pdf.cell(col_widths[0], 7, r["sin"], border=1, fill=True)
        pdf.cell(col_widths[1], 7, r["name"][:28], border=1, fill=True)  # Truncate long names
        pdf.cell(col_widths[2], 7, str(r["sessions_attended"]), border=1, fill=True, align="C")
        pdf.cell(col_widths[3], 7, str(r["total_sessions"]), border=1, fill=True, align="C")
        pdf.cell(col_widths[4], 7, f"{r['attendance_pct']}%", border=1, fill=True, align="C")
        pdf.cell(col_widths[5], 7, r["status"], border=1, fill=True, align="C")
        pdf.ln()
        fill = not fill

    pdf.output(filepath)
    print(f"[Export] Eligibility PDF saved: {filepath}")
    return filepath
