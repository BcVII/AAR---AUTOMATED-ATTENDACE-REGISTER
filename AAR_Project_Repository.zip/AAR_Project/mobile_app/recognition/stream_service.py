"""
==============================================================
 AAR - Stream Service
 SDS Section 3.2.2 - Synchronous Data Pipeline
==============================================================
 Manages the HTTP connection to the ESP32-CAM (Acquisition Node)
 and drives the recognition pipeline frame-by-frame.

 Flow (SDS 3.2.2):
   1. Stream Handshake: persistent HTTP GET to ESP32 IP:81/stream
   2. Frame Buffering: extract most recent frame, discard stale
   3. Inject into Recognition Engine
   4. On match → DB transaction commit
   5. Notify UI via callback

 Also implements the Analytics Layer timing rules (SDS 3.3.2 III):
   - 15-minute auto-disconnect (attendance window closes)
   - 105-minute lockout before next session can start
==============================================================
"""

import threading
import time
import datetime
import requests
import numpy as np
from typing import Optional, Callable, List, Tuple

from mobile_app.recognition.recognition_engine import process_frame_for_attendance, load_models
from mobile_app.database.db_manager import (
    mark_present,
    is_already_marked,
    open_session,
    get_registered_vectors,
)

# ─────────────────────────────────────────────────────────────
#  Timing Constants (SDS 3.3.2 - Analytics Layer)
# ─────────────────────────────────────────────────────────────
ATTENDANCE_WINDOW_SECONDS = 15 * 60      # 15 minutes (900s) – CBU "15-minute rule"
LOCKOUT_DURATION_SECONDS  = 105 * 60     # 105 minutes (6300s) – full lecture block cooldown

FRAME_PROCESS_INTERVAL    = 1.5          # Process one frame every 1.5 seconds
                                          # Balances accuracy vs CPU load on phone


class StreamService:
    """
    Manages the full lifecycle of an attendance session:
      - Connects to ESP32-CAM MJPEG stream
      - Processes frames and recognises students
      - Enforces timing policies
      - Reports events back to the UI via callbacks
    """

    def __init__(self):
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._is_streaming = False
        self._session_start: Optional[datetime.datetime] = None
        self._last_session_end: Optional[datetime.datetime] = None

        # Callbacks (set by UI layer)
        self.on_student_recognised: Optional[Callable[[str, str, float], None]] = None
        self.on_frame_update: Optional[Callable[[bytes], None]] = None
        self.on_error: Optional[Callable[[str], None]] = None
        self.on_session_closed: Optional[Callable[[], None]] = None
        self.on_status_update: Optional[Callable[[str], None]] = None

        # Session state
        self._course_id: Optional[str] = None
        self._registered_vectors: List[Tuple[str, str, np.ndarray]] = []
        self._recognised_today: set = set()  # SIN set – fast duplicate check in memory

    # ─────────────────────────────────────────────────────────
    #  Session Control
    # ─────────────────────────────────────────────────────────

    def can_start_session(self) -> Tuple[bool, str]:
        """
        Check if a new session can be started.
        Enforces the 105-minute lockout (SDS 3.3.2 Analytics Layer).
        Returns (can_start, reason_message).
        """
        if self._is_streaming:
            return False, "A session is already active."

        if self._last_session_end is not None:
            elapsed = (datetime.datetime.now() - self._last_session_end).total_seconds()
            if elapsed < LOCKOUT_DURATION_SECONDS:
                remaining = int((LOCKOUT_DURATION_SECONDS - elapsed) / 60)
                return False, f"Lockout active. Next session available in ~{remaining} minutes."

        return True, "Ready"

    def start_session(self, esp32_ip: str, course_id: str) -> bool:
        """
        Start an attendance session.
        Opens a DB session record, loads face vectors, begins streaming.
        Returns True if started successfully.
        """
        can_start, reason = self.can_start_session()
        if not can_start:
            self._notify_error(reason)
            return False

        self._course_id = course_id
        self._stop_event.clear()
        self._session_start = datetime.datetime.now()
        self._recognised_today.clear()

        # Load models if not already loaded
        try:
            load_models()
        except Exception as e:
            self._notify_error(f"Failed to load recognition models: {e}")
            return False

        # Open session in DB (records today's date for session counting)
        open_session(course_id)

        # Load all registered face vectors for this course
        self._registered_vectors = get_registered_vectors(course_id)
        if not self._registered_vectors:
            self._notify_status("WARNING: No registered students found for this course.")

        stream_url = f"http://{esp32_ip.strip()}:81/stream"
        self._is_streaming = True

        self._thread = threading.Thread(
            target=self._stream_worker,
            args=(stream_url,),
            daemon=True
        )
        self._thread.start()
        self._notify_status(f"Session started. Attendance window: 15 minutes.")
        return True

    def stop_session(self) -> None:
        """Manually stop the current session (e.g. user presses Stop)."""
        self._stop_event.set()
        self._is_streaming = False
        self._last_session_end = datetime.datetime.now()
        self._notify_status("Session closed manually.")
        if self.on_session_closed:
            self.on_session_closed()

    # ─────────────────────────────────────────────────────────
    #  Streaming Worker Thread
    # ─────────────────────────────────────────────────────────

    def _stream_worker(self, stream_url: str) -> None:
        """
        Main worker thread: connects to ESP32 MJPEG stream,
        extracts frames, drives recognition, enforces timing.
        """
        try:
            self._notify_status(f"Connecting to {stream_url}...")
            response = requests.get(stream_url, stream=True, timeout=10)

            if response.status_code != 200:
                self._notify_error(f"ESP32-CAM returned HTTP {response.status_code}")
                self._is_streaming = False
                return

            self._notify_status("Connected to ESP32-CAM. Scanning for faces...")

            bytes_buffer = b""
            last_process_time = 0.0

            for chunk in response.iter_content(chunk_size=4096):
                if self._stop_event.is_set():
                    break

                # ── Auto-close after 15-minute window (SDS 3.3.2 Analytics) ──
                elapsed = (datetime.datetime.now() - self._session_start).total_seconds()
                if elapsed >= ATTENDANCE_WINDOW_SECONDS:
                    self._notify_status("15-minute attendance window has closed. Disconnecting.")
                    break

                bytes_buffer += chunk

                # Extract JPEG frames from MJPEG stream
                # MJPEG frames are delimited by 0xFFD8...0xFFD9
                start = bytes_buffer.find(b"\xff\xd8")
                end   = bytes_buffer.find(b"\xff\xd9")

                if start != -1 and end != -1 and end > start:
                    jpeg_bytes = bytes_buffer[start:end + 2]
                    bytes_buffer = bytes_buffer[end + 2:]  # Discard processed data

                    # Rate-limit processing to avoid overloading phone CPU
                    now = time.time()
                    if (now - last_process_time) < FRAME_PROCESS_INTERVAL:
                        # Still send frame to UI for display even if not processing
                        if self.on_frame_update:
                            self.on_frame_update(jpeg_bytes)
                        continue

                    last_process_time = now
                    self._process_frame(jpeg_bytes)

        except requests.exceptions.ConnectionError:
            self._notify_error("Cannot connect to ESP32-CAM. Check IP address and WiFi hotspot.")
        except requests.exceptions.Timeout:
            self._notify_error("Connection to ESP32-CAM timed out.")
        except Exception as e:
            self._notify_error(f"Stream error: {e}")
        finally:
            self._is_streaming = False
            self._last_session_end = datetime.datetime.now()
            if self.on_session_closed:
                self.on_session_closed()

    def _process_frame(self, jpeg_bytes: bytes) -> None:
        """Process a single frame: recognise → log → notify UI."""
        try:
            match, annotated_frame = process_frame_for_attendance(
                jpeg_bytes, self._registered_vectors
            )

            # Update video display
            if self.on_frame_update and annotated_frame is not None:
                from mobile_app.recognition.recognition_engine import frame_to_jpeg_bytes
                self.on_frame_update(frame_to_jpeg_bytes(annotated_frame))

            if match is None:
                return

            sin, name, score = match

            # In-memory duplicate check (fast, before DB call)
            if sin in self._recognised_today:
                return

            # DB transaction: mark present (also does duplicate check)
            was_new = mark_present(self._course_id, sin, name)

            if was_new:
                self._recognised_today.add(sin)
                self._notify_status(f"Marked present: {name}")
                if self.on_student_recognised:
                    self.on_student_recognised(sin, name, score)

        except Exception as e:
            print(f"[StreamService] Frame processing error: {e}")

    # ─────────────────────────────────────────────────────────
    #  Notification Helpers
    # ─────────────────────────────────────────────────────────

    def _notify_error(self, msg: str) -> None:
        print(f"[StreamService][ERROR] {msg}")
        if self.on_error:
            self.on_error(msg)

    def _notify_status(self, msg: str) -> None:
        print(f"[StreamService] {msg}")
        if self.on_status_update:
            self.on_status_update(msg)

    @property
    def is_streaming(self) -> bool:
        return self._is_streaming

    @property
    def session_elapsed_seconds(self) -> float:
        if self._session_start is None:
            return 0.0
        return (datetime.datetime.now() - self._session_start).total_seconds()

    @property
    def session_time_remaining(self) -> float:
        """Seconds remaining in the 15-minute attendance window."""
        return max(0.0, ATTENDANCE_WINDOW_SECONDS - self.session_elapsed_seconds)
