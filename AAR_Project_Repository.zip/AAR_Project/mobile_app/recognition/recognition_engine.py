"""
==============================================================
 AAR - Recognition & Inference Engine
 SDS Section 3.3.2 - Layer II (Recognition & Inference Engine)
==============================================================
 Pipeline (as described in SDS):
   1. Receive raw MJPEG frame (JPEG bytes)
   2. OpenCV pre-processing:
        - Decode JPEG → NumPy array
        - Grayscale conversion (reduce compute load)
        - Haar Cascade → locate face coordinates
        - Crop & Affine Transform → normalize face
   3. InsightFace → 512-dimensional biometric vector
   4. Cosine similarity comparison against stored vectors
   5. Return matched student info or None

 CHANGE NOTE:
   InsightFace's buffalo_sc model is used instead of a raw
   Haar Cascade for the final recognition step because it
   provides the 512-dim vectors specified in the SDS.
   Haar Cascade is still used for fast face detection / pre-screening.
==============================================================
"""

import cv2
import numpy as np
from typing import Optional, Tuple, List
import insightface
from insightface.app import FaceAnalysis

# ─────────────────────────────────────────────────────────────
#  Globals – loaded once at startup
# ─────────────────────────────────────────────────────────────
_face_app: Optional[FaceAnalysis] = None
_haar_cascade: Optional[cv2.CascadeClassifier] = None

SIMILARITY_THRESHOLD = 0.45   # Cosine distance threshold (lower = stricter)
                               # Tune between 0.35 (strict) and 0.55 (lenient)


def load_models() -> None:
    """
    Load InsightFace and Haar Cascade models into memory.
    Call once at application startup.
    InsightFace will download buffalo_sc (~30MB) on first run.
    """
    global _face_app, _haar_cascade

    print("[Recognition] Loading InsightFace model (buffalo_sc)...")
    _face_app = FaceAnalysis(
        name="buffalo_sc",          # Lightweight model suitable for mobile CPUs
        providers=["CPUExecutionProvider"]
    )
    _face_app.prepare(ctx_id=0, det_size=(320, 320))
    print("[Recognition] InsightFace model loaded.")

    # Haar Cascade for fast face detection pre-screening
    cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    _haar_cascade = cv2.CascadeClassifier(cascade_path)
    print("[Recognition] Haar Cascade loaded.")


def _ensure_models_loaded() -> None:
    if _face_app is None:
        load_models()


# ─────────────────────────────────────────────────────────────
#  Frame Decoding
# ─────────────────────────────────────────────────────────────

def decode_jpeg_frame(jpeg_bytes: bytes) -> Optional[np.ndarray]:
    """
    Convert raw JPEG bytes from ESP32-CAM stream into a BGR NumPy array.
    Returns None if decoding fails.
    """
    try:
        nparr = np.frombuffer(jpeg_bytes, dtype=np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        return frame
    except Exception as e:
        print(f"[Recognition] Frame decode error: {e}")
        return None


# ─────────────────────────────────────────────────────────────
#  Pre-processing (SDS 3.3.2 - OpenCV Pipeline)
# ─────────────────────────────────────────────────────────────

def preprocess_frame(frame: np.ndarray) -> Tuple[np.ndarray, List]:
    """
    OpenCV pre-processing pipeline (as described in SDS 3.3.2):
      1. Convert to grayscale to reduce computational load
      2. Apply histogram equalisation for poor lighting (SDS 1.6.1 mitigation)
      3. Run Haar Cascade to locate face regions
      4. Return normalised face crops

    Returns:
        (processed_frame, face_rects)
        face_rects: list of (x, y, w, h) tuples
    """
    _ensure_models_loaded()

    # Step 1: Grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Step 2: Histogram equalisation (lighting normalisation – Kumar & Singh 2023)
    equalized = cv2.equalizeHist(gray)

    # Step 3: Haar Cascade face detection
    faces = _haar_cascade.detectMultiScale(
        equalized,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(60, 60)
    )

    face_rects = []
    if len(faces) > 0:
        for (x, y, w, h) in faces:
            # Add small padding around face (10%)
            pad = int(0.1 * w)
            x1 = max(0, x - pad)
            y1 = max(0, y - pad)
            x2 = min(frame.shape[1], x + w + pad)
            y2 = min(frame.shape[0], y + h + pad)
            face_rects.append((x1, y1, x2 - x1, y2 - y1))

    return frame, face_rects


# ─────────────────────────────────────────────────────────────
#  Face Embedding Extraction
# ─────────────────────────────────────────────────────────────

def extract_embedding(frame: np.ndarray) -> Optional[np.ndarray]:
    """
    Run InsightFace on a full frame to extract a 512-dim embedding.
    Returns the embedding vector of the largest detected face, or None.
    This is the biometric vector used for registration and recognition.
    """
    _ensure_models_loaded()

    faces = _face_app.get(frame)
    if not faces:
        return None

    # Take the largest (most prominent) face
    largest_face = max(faces, key=lambda f: (f.bbox[2] - f.bbox[0]) * (f.bbox[3] - f.bbox[1]))
    embedding = largest_face.normed_embedding  # 512-dim normalized vector
    return embedding.astype(np.float32)


# ─────────────────────────────────────────────────────────────
#  Biometric Identification (SDS 3.3.2 - Cross-Referencing)
# ─────────────────────────────────────────────────────────────

def cosine_similarity(vec_a: np.ndarray, vec_b: np.ndarray) -> float:
    """Compute cosine similarity between two L2-normalized vectors."""
    return float(np.dot(vec_a, vec_b))


def identify_student(
    live_embedding: np.ndarray,
    registered_vectors: List[Tuple[str, str, np.ndarray]]
) -> Optional[Tuple[str, str, float]]:
    """
    Compare a live face embedding against all registered student vectors.
    Uses cosine similarity (InsightFace vectors are already L2-normalized).

    Args:
        live_embedding:     512-dim vector from the camera feed
        registered_vectors: list of (sin, name, vector) from DB

    Returns:
        (sin, name, similarity_score) if match found above threshold
        None if no match
    """
    if not registered_vectors:
        return None

    best_match = None
    best_score = -1.0

    for (sin, name, stored_vec) in registered_vectors:
        if stored_vec is None:
            continue
        score = cosine_similarity(live_embedding, stored_vec)
        if score > best_score:
            best_score = score
            best_match = (sin, name)

    if best_score >= (1.0 - SIMILARITY_THRESHOLD):
        return (best_match[0], best_match[1], best_score)

    return None


# ─────────────────────────────────────────────────────────────
#  Full Recognition Pipeline
# ─────────────────────────────────────────────────────────────

def process_frame_for_attendance(
    jpeg_bytes: bytes,
    registered_vectors: List[Tuple[str, str, np.ndarray]]
) -> Tuple[Optional[Tuple[str, str, float]], Optional[np.ndarray]]:
    """
    Full pipeline from raw MJPEG frame bytes to student identification.
    Called by the streaming service on each clean frame.

    Returns:
        (match_result, annotated_frame)
        match_result: (sin, name, score) or None
        annotated_frame: BGR frame with bounding box drawn (for UI display)
    """
    frame = decode_jpeg_frame(jpeg_bytes)
    if frame is None:
        return None, None

    processed_frame, face_rects = preprocess_frame(frame)

    if not face_rects:
        return None, frame  # No face detected

    # Draw face bounding boxes on the display frame
    annotated = frame.copy()
    for (x, y, w, h) in face_rects:
        cv2.rectangle(annotated, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # Extract embedding from full frame (InsightFace handles its own detection)
    embedding = extract_embedding(frame)
    if embedding is None:
        return None, annotated

    # Identify student
    match = identify_student(embedding, registered_vectors)

    if match:
        sin, name, score = match
        # Draw name label on frame
        cv2.putText(
            annotated, f"{name} ({score:.2f})",
            (face_rects[0][0], face_rects[0][1] - 10),
            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2
        )
    else:
        cv2.putText(
            annotated, "Unknown",
            (face_rects[0][0], face_rects[0][1] - 10),
            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2
        )

    return match, annotated


# ─────────────────────────────────────────────────────────────
#  Utilities
# ─────────────────────────────────────────────────────────────

def frame_to_jpeg_bytes(frame: np.ndarray, quality: int = 85) -> bytes:
    """Convert a NumPy BGR frame to JPEG bytes for display in Toga UI."""
    _, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, quality])
    return buf.tobytes()


def frame_to_png_bytes(frame: np.ndarray) -> bytes:
    """Convert a NumPy BGR frame to PNG bytes for display in Toga UI."""
    _, buf = cv2.imencode(".png", frame)
    return buf.tobytes()
