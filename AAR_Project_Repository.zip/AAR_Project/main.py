"""
==============================================================
 AAR - Automated Attendance Register
 Main Application Entry Point
==============================================================
 Run this file to start the application:
   python main.py

 Requirements:
   pip install -r requirements.txt

 NOTE ON FRAMEWORK CHANGE:
   The original proposal specified Kivy. After evaluation, this
   implementation uses BeeWare/Toga (as stated in the System
   Design Specification, Section 3.3.2). Toga provides better
   native Android UI widgets and is referenced in the SDS.
   For desktop testing, Toga renders as a native desktop window.
   For Android deployment, use the `briefcase` tool (see README).
==============================================================
"""

import toga
from mobile_app.ui.main_window import AARApp

if __name__ == "__main__":
    app = AARApp(
        formal_name="Automated Attendance Register",
        app_id="com.cbu.aar",
        app_name="AAR",
    )
    app.main_loop()
